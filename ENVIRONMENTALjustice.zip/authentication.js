  // firebase config
  var firebaseConfig = {
    apiKey: "AIzaSyAAIqZ_Ks_7nW3rOmXDYW2jAvjP-grc7ac",
    authDomain: "filter-events.firebaseapp.com",
    databaseURL: "https://filter-events.firebaseio.com",
    projectId: "filter-events",
    storageBucket: "filter-events.appspot.com",
    messagingSenderId: "574914814609",
    appId: "1:574914814609:web:1ebbeaa201e0b13c10d530",
    measurementId: "G-54HGPCK89F"
  };
  // initialize firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();

// initialize firebase ui widget 
var ui = new firebaseui.auth.AuthUI(firebase.auth());
var database=firebase.firestore();

ui.start( '#firebaseui-auth-container', {
  signInOptions: [
    firebase.auth.GoogleAuthProvider.PROVIDER_ID,
  ],
});


var uiConfig = {
  callbacks: {
    signInSuccessWithAuthResult: function(authResult, redirectUrl) {
      return true;
    },
    uiShown: function() {
      document.getElementById('loader').style.display = 'none';
    }
  },
  signInFlow: 'popup',
  signInSuccessUrl: 'forum.html',
  signInOptions: [
    firebase.auth.GoogleAuthProvider.PROVIDER_ID,
  ],
};

ui.start('#firebaseui-auth-container', uiConfig);

var data = null;

var anonymousUser = firebase.auth().currentUser;
ui.start('#firebaseui-auth-container', {

  autoUpgradeAnonymousUsers: true,
  signInSuccessUrl: 'forum.html',
  signInOptions: [
    firebase.auth.GoogleAuthProvider.PROVIDER_ID
  ],
  callbacks: {

    signInFailure: function(error) {

      if (error.code != 'firebaseui/anonymous-upgrade-merge-conflict') {
        return Promise.resolve();
      }

      var cred = error.credential;

      return firebase.auth().signInWithCredential(cred);
    }
  }
});

// get user info
var user = firebase.auth().currentUser;
var name, email, photoUrl, uid, emailVerified;
if (user != null) {
  name = user.displayName;
  email = user.email;
  photoUrl = user.photoURL;
  emailVerified = user.emailVerified;
  uid = user.uid;  
}

firebase.auth().onAuthStateChanged(user => {
if (user) {
// when user is signed in
    $('#hello-user').append(`Hi, ${user.displayName}:`)
    $('#firebaseui-auth-container').addClass('hide');
    $('#my-events-description').css('display','none');
    if (user.displayName) {
      document.getElementById('display-name-header').textContent = `${user.displayName}`
    }
    if (user.photoURL) {
      document.getElementById('profile-pic').src=user.photoURL;
    }
  // get the event form for item submissions
  let toDoListForm = document.querySelectorAll('.to-do-list-form');
  let addBtn = document.querySelectorAll('.add');

    database.collection('event-list').doc(user.uid).collection('my-events').orderBy('date','asc')
    .onSnapshot(snapshot => {
			document.getElementById('to-do-list-items').innerHTML = '';
			snapshot.forEach(element => {
				let p = document.createElement('p');
				p.textContent = element.data().item;
				let deleteButton = document.createElement('button');
				deleteButton.textContent = 'x';
				deleteButton.classList.add('delete-button');
				deleteButton.setAttribute('data', element.id);
				p.appendChild(deleteButton);
				document.getElementById('to-do-list-items').appendChild(p);
			});
		});

    for ( let i = 0; i < addBtn.length; i++){
    addBtn[i].addEventListener('click', () => {
      event.preventDefault();
      console.log(addBtn[i])
      //addBtn[i].className = "hide"
      addItems(myArray[i]);
    })
    }


  function addItems(eventItem){
	  // send value to Firebase
	  database.collection('event-list').doc(user.uid).collection('my-events').add({
		// grab value from form
		item: eventItem.event,
    date: firebase.firestore.Timestamp.fromMillis(Date.now())
	});
  }

  // delete an event item
  document.body.addEventListener('click', event => {
	  if (event.target.matches('.delete-button')) {
		key = event.target.getAttribute('data');
		database.collection('event-list').doc(user.uid).collection('my-events').doc(key).delete();

    };
  

});

  $('.profile-container').on("click", dropdown)
  function dropdown() {
    console.log("click")
    $('.sign-out').toggleClass('show');
  }

document.querySelector('#message-form').addEventListener('submit', e => {
    e.preventDefault();
    var currentdate = new Date(); 
    var datetime =  (currentdate.getMonth()+1)  + "/"
                + currentdate.getDate() + "/" 
                + currentdate.getFullYear() + " "
                + (currentdate.getHours()) + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds();
    // 1. get form values
    let message = document.querySelector('#message-input').value
    let header = document.querySelector('#header-input').value

    // 2. save the form value to the database
    //adds a message to a collection called "messages", and if the collection doesn't exist already, it will create it
    database.collection('messages').add({
      name: user.displayName,
      header: header,
      message: message,
      //generate current time in milliseconds
      date: firebase.firestore.Timestamp.fromMillis(Date.now()),
      createdAt: datetime
    })
    // 3. return as promise
    .then((docRef) => {
      console.log(`Document written with ID: ${docRef.id}`);
      // 4. clears text input
      document.querySelector('#message-form').reset()
    })
    .catch((error) => {
      console.error(`Error adding document: ${error}`);
    })
  })

    database.collection('messages')
  //show messages in ascending order
  .orderBy('date','asc')
  .onSnapshot(snapshot => {
    document.querySelector('#messages').innerHTML = ''
    snapshot.forEach(doc => {
      let message = document.createElement('div')
      message.innerHTML = `
      <h2>${doc.data().header}</h2>
      <p class = "name">${doc.data().name} - <span style="font-weight:normal">${doc.data().createdAt}</span></p>
      <p style="font-weight:normal">${doc.data().message}</p>`
    	let deleteButton = document.createElement('button');
      deleteButton.textContent = 'Delete';
			deleteButton.classList.add('delete-button1');
			deleteButton.setAttribute('data', doc.id);
      message.appendChild(deleteButton);
      document.querySelector('#messages').prepend(message)

    // delete an event item
    document.body.addEventListener('click', event => {
	  if (event.target.matches('.delete-button1')){
        console.log("deleted")
		    key = event.target.getAttribute('data');
		    database.collection('messages').doc(key).delete();
    };
    })
  })

  })
} else {
  //when user is signed out
      document.getElementById('display-name-header').textContent = '';
      document.getElementById('profile-pic').src='';
      $("#to-do-list-items").addClass('hide');
      $('.profile-container').css('display', 'none');
      $('.add').attr('disabled','disabled');
      $('#firebaseui-auth-container').removeClass('hide');
      $('.sign-out').css('display','none')
      $('#my-events-description').css('display','block');
      $('#hello-user').css('display','none');
      $('#messages').css('display','none');
}
});

$('.sign-out').on("click",signOut)

function signOut() {
firebase.auth().signOut().then(function() {
  console.log('Sign-out successful')
}).catch(function(error) {
  // an error happened
});
}

