  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyAAIqZ_Ks_7nW3rOmXDYW2jAvjP-grc7ac",
    authDomain: "filter-events.firebaseapp.com",
    databaseURL: "https://filter-events.firebaseio.com",
    projectId: "filter-events",
    storageBucket: "filter-events.appspot.com",
    messagingSenderId: "574914814609",
    appId: "1:574914814609:web:1ebbeaa201e0b13c10d530",
    measurementId: "G-54HGPCK89F"
  };
  // Initialize Firebase
  if (!firebase.apps.length) {
   firebase.initializeApp({});
  }
  firebase.analytics();

// Reference to database method of Firebase


var myArray = [
    {
    event:'Healthy Homes Working Group Looks at NYCHA’s New Blueprint for Change Plan',
    date: 'August 18, 2020',link:'https://www.weact.org/event/healthy-homes-working-group-looks-at-nychas-new-blueprint-for-change-plan/',add:'Add'},

    { 
      event:'Acterra’s Young Professionals: Taking Action for Environmental Justice', 
      date: 'August 20, 2020',link:'https://www.eventbrite.com/e/acterras-young-professionals-taking-action-for-environmental-justice-tickets-115433714347?aff=ebdssbonlinesearch',
      add:'Add'},

    {
      event:'Alternate Currents Panel Discussion: Environmental Justice', 
      date: 'August 20, 2020',link:'https://www.eventbrite.com/e/alternate-currents-panel-discussion-environmental-justice-tickets-114471122208?aff=ebdssbonlinesearch',
      add:'Add'},


    { 
      event:'Toward Racial Justice: A Conversation on Environmental Justice', 
      date: 'August 27, 2020',link:'https://www.eventbrite.com/e/toward-racial-justice-a-conversation-on-environmental-justice-tickets-117021611791?aff=ebdssbonlinesearch',
      add:'Add'},

    {
      event:'Toxic Expertise Webinar Series: Struggles for Environmental Justice',
      date: 'September 2, 2020', link:'https://www.eventbrite.co.uk/e/toxic-expertise-webinar-series-struggles-for-environmental-justice-tickets-116763062463?aff=ebdssbonlinesearch',
      add:'Add'},

    {
      event:'Environmental Justice: Indigenous Communities',
      date: 'November 5, 2020',
      link:'https://www.eventbrite.com/e/environmental-justice-indigenous-communities-tickets-115909098233?aff=ebdssbonlinesearch',
      add:'Add'}
]

$('#search-input').on('keyup', function(){
    var value = $(this).val()
    console.log('Value: ', value)
    var data= searchTable(value,myArray)
    buildTable(data)
})

$('#search-input1').on('keyup', function(){
    var value = $(this).val()
    console.log('Value: ', value)
    var data= searchTable1(value,myArray)
    buildTable(data)
})

buildTable(myArray)

function searchTable(value, data){
    var filteredData = []

    for (var i = 0; i < data.length; i++){
        value = value.toLowerCase()
        var event = data[i].event.toLowerCase()

        if (event.includes(value)){
            filteredData.push(data[i])
        }
    }
    return filteredData
}

function searchTable1(value, data){
    var filteredData = []

    for (var i = 0; i < data.length; i++){
        value = value.toLowerCase()
        var date = data[i].date.toLowerCase()

        if (date.includes(value)){
            filteredData.push (data[i])
        }
    }
    return filteredData
}

 $('th').on('click', function(){
     var column = $(this).data('colcity')
     var order = $(this).data('order')
     var text = $(this).html()
     text = text.substring(0, text.length - 1);
     
     if (order == 'desc'){
        myArray = myArray.sort((a, b) => a[column] > b[column] ? 1 : -1)
        $(this).data("order","asc");
        text += '&#9660'
     }else{
        myArray = myArray.sort((a, b) => a[column] < b[column] ? 1 : -1)
        $(this).data("order","desc");
        text += '&#9650'
     }

    $(this).html(text)
    buildTable(myArray)
    })

     
function buildTable(data){
    var table = document.getElementById('myTable')
    table.innerHTML = ''
    for (var i = 0; i < data.length; i++){
        var colevent = `event-${i}`
        var coldate = `date-${i}`
        var collink = `link-${i}`
        var coladd = `add-${i}`

        var row = `<tr>
                        <form class="to-do-list-form">
                        <td id="item">${data[i].event}</td>
                        <td>${data[i].date}</td>
                        <td><a href=${data[i].link}>Link</a></td>
                        <td><button class="add" id="test" type="submit">${data[i].add}</button></td>
                        </form>
                   </tr>`
        table.innerHTML += row
    }
}

$('.getInvolvedBtn').on("click", getInvolved)
function getInvolved(){
  $('.getInvolvedLink').toggleClass('show');
  console.log('test')
}





